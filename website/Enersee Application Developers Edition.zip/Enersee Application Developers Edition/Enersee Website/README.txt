In order to run Enersee.jar you need to install Rxtx on your computer correctly.

Installing RXTX on Windows:

Navigate to: http://rxtx.qbang.org/wiki/index.php/Download

Download the rxtx-2.1-7-bins-r2.zip file and extract the files. 
You should now have a folder that contains several other folders like Windows, Mac OS X and Linux.
In the Windows\i386-mingw32 folder, copy the rxtxSerial.dll file and navigate to the Java\jre6\bin folder on your computer. 
On most Windows computers Java is installed at C:\Program Files\Java.
Place this rxtxSerial.dll file in the Java\jre6\bin folder. 

You should now be able to double click on the Enersee.jar file that you have downloaded and have it run the application.
If not, check to make sure you have place the file in the right folder. 



Installing RXTX on Mac OS X:

Navigate to: http://rxtx.qbang.org/wiki/index.php/Download
 
Download the rxtx-2.1-7-bins-r2.zip file and extract the files. 
You should now have a folder that contains several other folders like Windows, Mac OS X and Linux.
In the Mac OS X folder, copy the librxtxSerial.jnilib file and navigate to the Macintosh HD\Library\Java\Extensions folder on your computer. 
Place this librxtxSerial.jnilib file in the Java\jre6\bin folder. 

You should now be able to double click on the Enersee.jar file that you have downloaded and have it run the application.
If not, check to make sure you have place the file in the right folder. 
